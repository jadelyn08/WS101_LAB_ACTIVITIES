
const API_BASE_URL = 'http://localhost:8080';
const ENDPOINT_PREFIX = '/api';

// Build full endpoint helper
function getEndpoint(path) {
    const fullPath = `${API_BASE_URL}${ENDPOINT_PREFIX}${path}`;
    console.log(`Fetching: ${fullPath}`); // Debug log
    return fullPath;
}

// Elements (assumes these IDs exist in your HTML)
const createForm = document.getElementById('createForm');
const editForm = document.getElementById('editForm');
const todosList = document.getElementById('todosList');
const errorMessage = document.getElementById('errorMessage');

// Function to show error message
function showError(msg) {
    console.error(msg); // Log to console for debugging
    if (errorMessage) {
        errorMessage.textContent = msg;
        errorMessage.style.display = 'block';
        setTimeout(() => {
            errorMessage.style.display = 'none';
        }, 5000);
    }
}

// Function to hide error message
function hideError() {
    if (errorMessage) {
        errorMessage.style.display = 'none';
    }
}

// Function to fetch and display todos
async function fetchTodos() {
    try {
        hideError();
        if (todosList) {
            todosList.innerHTML = '<div class="loading">Loading todos...</div>';
        }
        
        const response = await fetch(getEndpoint('/todos'));
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status} - ${response.statusText}`);
        }
        const todos = await response.json();
        console.log('Fetched todos:', todos); // Debug log
        
        if (todosList && todos.length === 0) {
            todosList.innerHTML = '<p>No todos found.</p>';
            return;
        }
        
        if (todosList) {
            todosList.innerHTML = todos.map(todo => `
                <li>
                    <div class="todo-content">
                        <div class="todo-title">${todo.title}</div>
                        <div class="todo-description">${todo.description}</div>
                        ${todo.completed ? '<div class="todo-completed">Completed</div>' : ''}
                    </div>
                    <div>
                        <button class="edit-btn" onclick="editTodo(${todo.id}, '${todo.title.replace(/'/g, "\\'")}', '${todo.description.replace(/'/g, "\\'")}', ${todo.completed})">Edit</button>
                        <button class="delete-btn" onclick="deleteTodo(${todo.id})">Delete</button>
                    </div>
                </li>
            `).join('');
        }
    } catch (error) {
        console.error('Error fetching todos:', error);
        if (todosList) {
            todosList.innerHTML = '<p>Error loading todos. Please try again.</p>';
        }
        showError('HAHA puki: ' + error.message);
    }
}

// Function to create a new todo
async function createTodo(title, description, completed) {
    try {
        const response = await fetch(getEndpoint('/todos'), {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                title,
                description,
                completed: completed || false
            })
        });
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`HTTP error! status: ${response.status} - ${errorText}`);
        }
        // Reset form
        const titleInput = document.getElementById('title');
        const descInput = document.getElementById('description');
        const completedInput = document.getElementById('completed');
        if (titleInput) titleInput.value = '';
        if (descInput) descInput.value = '';
        if (completedInput) completedInput.checked = false;
        // Refresh list
        fetchTodos();
    } catch (error) {
        console.error('Error creating todo:', error);
        showError('Failed to create todo: ' + error.message);
    }
}

// Function to update a todo
async function updateTodo(id, title, description, completed) {
    try {
        const response = await fetch(getEndpoint(`/todos/${id}`), {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                id,
                title,
                description,
                completed: completed || false
            })
        });
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`HTTP error! status: ${response.status} - ${errorText}`);
        }
        // Hide edit form and reset
        if (editForm) editForm.style.display = 'none';
        if (createForm) createForm.style.display = 'block';
        // Refresh list
        fetchTodos();
    } catch (error) {
        console.error('Error updating todo:', error);
        showError('Failed to update todo: ' + error.message);
    }
}

// Function to delete a todo
async function deleteTodo(id) {
    if (!confirm('Are you sure you want to delete this todo?')) {
        return;
    }
    try {
        const response = await fetch(getEndpoint(`/todos/${id}`), {
            method: 'DELETE'
        });
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`HTTP error! status: ${response.status} - ${errorText}`);
        }
        // Refresh list
        fetchTodos();
    } catch (error) {
        console.error('Error deleting todo:', error);
        showError('Failed to delete todo: ' + error.message);
    }
}

// Function to populate edit form
function editTodo(id, title, description, completed) {
    const editIdInput = document.getElementById('editId');
    const editTitleInput = document.getElementById('editTitle');
    const editDescInput = document.getElementById('editDescription');
    const editCompletedInput = document.getElementById('editCompleted');
    if (editIdInput) editIdInput.value = id;
    if (editTitleInput) editTitleInput.value = title;
    if (editDescInput) editDescInput.value = description;
    if (editCompletedInput) editCompletedInput.checked = completed;
    if (editForm) editForm.style.display = 'block';
    if (createForm) createForm.style.display = 'none'; // Hide create form while editing
}

// Cancel edit
if (document.getElementById('cancelEdit')) {
    document.getElementById('cancelEdit').addEventListener('click', () => {
        if (editForm) editForm.style.display = 'none';
        if (createForm) createForm.style.display = 'block';
    });
}

// Event listeners (attach after DOM is ready)
if (createForm) {
    createForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const title = document.getElementById('title').value;
        const description = document.getElementById('description').value;
        const completed = document.getElementById('completed').checked;
        createTodo(title, description, completed);
    });
}

if (editForm) {
    editForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const id = document.getElementById('editId').value;
        const title = document.getElementById('editTitle').value;
        const description = document.getElementById('editDescription').value;
        const completed = document.getElementById('editCompleted').checked;
        updateTodo(id, title, description, completed);
    });
}

// Initial load (call after DOM is ready)
document.addEventListener('DOMContentLoaded', fetchTodos);