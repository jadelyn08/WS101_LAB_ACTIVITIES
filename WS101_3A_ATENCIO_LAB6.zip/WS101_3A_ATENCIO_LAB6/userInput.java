import java.util.Scanner;

class userInput {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);

        System.out.print("Enter your Name: ");
        String name = scn.nextLine(); 

        System.out.print("Enter your Age: ");
        int age = scn.nextInt();       

        System.out.println("Hi, you are " + name + " and you're already " + age + " years old.");

        scn.close();
    }
}

