import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);

        System.out.print("Enter length: ");
        double length = scn.nextDouble();

        System.out.print("Enter width: ");
        double width = scn.nextDouble();

        // Create Rectangle object
        Rectangle rect = new Rectangle(length, width);

        // Print area
        System.out.println("Area of the rectangle: " + rect.calculateArea());

        scn.close();
    }
}
