import java.util.Scanner;

public class Palindrome {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String input = scn.nextLine();

        String cleaned = input.replaceAll("\\s+", "").toLowerCase();

        String reversed = "";

        for (int i = cleaned.length() - 1; i >= 0; i--) {
            reversed += cleaned.charAt(i);
        }

        if (cleaned.equals(reversed)) {
            System.out.println("✔ The string is a palindrome.");
        } else {
            System.out.println("✘ The string is NOT a palindrome.");
        }

        scn.close();
    }
}

