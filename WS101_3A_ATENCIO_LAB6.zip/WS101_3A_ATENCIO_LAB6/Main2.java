import java.util.ArrayList;

public class Main2 {
    public static void main(String[] args) {
        ArrayList<Product> products = new ArrayList<>();

        products.add(new Product("Soap", 25));
        products.add(new Product("Shampoo", 75));
        products.add(new Product("Toothpaste", 60));
        products.add(new Product("Perfume", 150));
        products.add(new Product("Candy", 10));

        long count = products.stream()
                             .filter(p -> p.price > 50)
                             .count();

        System.out.println("Number of products with price greater than 50: " + count);
    }
}
